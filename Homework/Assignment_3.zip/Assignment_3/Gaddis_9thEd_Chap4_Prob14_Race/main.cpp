/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 12, 2022
 * sorts race times by fastest and runner names 
 *           
 */
#include <iostream> 
#include <iomanip>//Input/Output Library
using namespace std;


int main(int argc, char** argv) {
    //Set the random number seed
   
  cout<<" Race Ranking Program"<<endl;  
    //Declare Variables
  string   x,
           y,
           z;
float timex,//time of first runner 
      timey,
      timez;
 cout<<"Input 3 Runners"<<endl;
 cout<<"Their names, then thier times"<<endl;
 cin>>x>>timex>>y>>timey>>z>>timez;
 if(timex <0 ||timey < 0|| timez < 0){
     cout<<"error"<<endl;
 }
 
 if (timex<=timey && timey<=timez) {//first runner time and combinations
     cout<<x<<setw(6)<<timex<<endl;
     cout<<y<<setw(6)<<timey<<endl;
     cout<<z<<setw(6)<<timez;
 }
  else if (timex<=timez && timez<=timey) {
     cout<<x<<setw(6)<<timex<<endl;
     cout<<z<<setw(6)<<timez<<endl;
     cout<<y<<setw(6)<<timey;
 }
  else if ( timey<=timex && timex<=timez) {//second runner times
     cout<<y<<setw(6)<<timey<<endl;
     cout<<x<<setw(6)<<timex<<endl;
     cout<<z<<setw(6)<<timez;
 }
 else if ( timey<=timez && timez<=timex) {
     cout<<y<<setw(6)<<timey<<endl;
     cout<<z<<setw(6)<<timez<<endl;
     cout<<x<<setw(6)<<timex;
 }
 else if (timez<=timex && timex<=timey){ //third runner
     cout<<z<<setw(6)<<timez<<endl;
     cout<<x<<setw(6)<<timex<<endl;
     cout<<y<<setw(6)<<timey;
 }
   else { 
     cout<<z<<setw(6)<<timez<<endl;
     cout<<y<<setw(6)<<timey<<endl;
     cout<<x<<setw(6)<<timex;
 }
    return 0;
}
