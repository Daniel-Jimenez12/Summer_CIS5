/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 12, 2022
 * calculates points gained from book club and purchases
 *           
 */

//System Libraries
#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    int books,
      points;
      
 
    
    cout<<"Book Worm Points"<<endl;
    //Declare Variables
    cout<<"Input the number of books purchased this month."<<endl;
    //Initialize or input i.e. set variable values
    cin>>books;
    //Map inputs -> outputs
    cout<<"Books purchased =  "<<books<<endl;
     
     if (books>=4) {//if book bought is more than 4 points equals 60
          points=60;
      cout<<"Points earned   = "<<setw(2)<<points;
    }
     else if(books == 1){// 1 book purchase 
       points = 5;
      cout<<"Points earned   = "<<setw(2)<<points;
     }
     else if(books == 2){//2 book purchases 
         points=15;
        cout<<"Points earned   = "<<setw(2)<<points;
    }
     else if(books == 3){//3 book purchase 
     points = 30;
     cout<<"Points earned   = "<<setw(2)<<points;
     }
     else{
         points = 0;
       cout<<"Points earned   = "<<setw(2)<<points;   
    
     }
     //cout<<"Points earned   = "<<setw(2)<<points;

    return 0;
}