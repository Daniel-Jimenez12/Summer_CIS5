/*Daniel Jimenez
* July 12 2022 
*calculates service provider bill 
*/
#include <iostream>  //Input/Output Library
using namespace std;
int main(int argc, char** argv) {
char package;

int hours;

float 
      bill,
    hourfee;//fee if past hour limit
bill = 0;

cout<<"ISP Bill"<<endl;

cout<<"Input Package and Hours"<<endl;
cin>>package>>hours;

 if(hours >= 744){
     cout<<"error"<<endl;
     
 }
 
if (package == 'A'&& hours > 10 ){
   
    bill=bill+9.95;
    hourfee+=(hours-10)*2;//fee for going over 10 hours
    bill+=hourfee;
    cout<<"Bill = $ "<<bill;//new bill total with all fees
    
}else if(package == 'A' && hours <= 10){
    
    bill+=9.95;
    cout<<"Bill = $ "<<bill;
}
if (package == 'a'&& hours > 10 ){
   
    bill=bill+9.95;
    hourfee+=(hours-10)*2;//fee for going over 10 hours
    bill+=hourfee;
    cout<<"Bill = $ "<<bill;//new bill total with all fees
    
}else if(package == 'a' && hours <= 10){
    
    bill+=9.95;
    cout<<"Bill = $ "<<bill;
}
if (package == 'B'&& hours > 20 ){
   
    bill=bill+14.95;
    hourfee+=(hours-20)*1;//fee for going over 20 hours
    bill+=hourfee;
    cout<<"Bill = $ "<<bill;
    
}else if(package == 'B' && hours <= 20){
    
    bill+=14.95;
    cout<<"Bill = $ "<<bill;
}
if (package == 'b'&& hours > 20 ){
   
    bill=bill+14.95;
    hourfee+=(hours-20)*1;//fee for going over 20 hours
    bill+=hourfee;
    cout<<"Bill = $ "<<bill;
    
}else if(package == 'b' && hours <= 20){
    
    bill+=14.95;
    cout<<"Bill = $ "<<bill;
}
if (package == 'C'){//c has unlimited hours so no need for else exception
   
    bill=bill+19.95;
    cout<<"Bill = $ "<<bill;
}
if (package == 'c'){//c has unlimited hours so no need for else exception
   
    bill=bill+19.95;
    cout<<"Bill = $ "<<bill;
}


return 0;
}
