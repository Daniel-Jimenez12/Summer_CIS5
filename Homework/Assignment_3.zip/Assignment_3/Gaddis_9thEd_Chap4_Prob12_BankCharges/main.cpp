/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 12, 2022
 * bank fees for a month calculator
 *           
 */

//System Libraries
#include <iostream> 
#include<iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
   
   float 
         checks,
         lowbal,
           fee,
         month,
        newbal,
        ten,
        eight,
        six,
        four,
       balance;
       
       
       ten =.10;//fewer than 20 checks fee per check
       eight =.08;//20-39 checks fee per check 
       six = .06;//40-59 fee 
       four = .04;//60 or more checks fee
       fee = 0;//fee cost 
     month = 10;//monthly fee  
     newbal=0;//new balance
     lowbal=15;//fee of 15 dollars for low balance under 400
     
   cout<<"Monthly Bank Fees"<<endl;
   
   cin>>balance>>checks;
   
   cout<<"Input Current Bank Balance and Number of Checks"<<endl;
    if(balance < 400){
        newbal+=lowbal;//new balance plus low balance fee
}
   if(checks < 0){
         
       cout<<"Urgent Message !: account Overdrawn ."<<endl;
       exit(1);
 } 
   else 
   

   
   if(checks >= 0 && checks < 20){//fewer than 20 checks
                       
    fee = checks*ten;
     newbal+=fee;
       cout<<setprecision(2)<<fixed;  
   cout<<"Balance"<<setw(6)<<"$"<<setw(9)<<balance<<endl;
   cout<<"Check Fee"<<setw(4)<<"$"<<setw(9)<<fee<<endl;
 
   cout<<"Monthly Fee"<<setw(2)<<"$"<<setw(9)<<month<<endl;
   cout<<"Low Balance"<<setw(2)<<"$"<<setw(9)<<lowbal<<endl;
      
  
        newbal+=month;
   newbal=balance-newbal;//new balance including check fees
 
   cout<<"New Balance"<<setw(2)<<"$"<<setw(9)<<newbal;
} 
   else if (checks >=20 && checks <=39){//checks between 20 and 39

    fee = checks*eight;
     newbal+=fee;
       cout<<setprecision(2)<<fixed;  
   cout<<"Balance"<<setw(6)<<"$"<<setw(9)<<balance<<endl;
   cout<<"Check Fee"<<setw(4)<<"$"<<setw(9)<<fee<<endl;
 
   cout<<"Monthly Fee"<<setw(2)<<"$"<<setw(9)<<month<<endl;
   cout<<"Low Balance"<<setw(2)<<"$"<<setw(9)<<lowbal<<endl;
      
  
        newbal+=month;
   newbal=balance-newbal;//new balance including check fees
 
   cout<<"New Balance"<<setw(2)<<"$"<<setw(9)<<newbal;
}
    else if(checks >=40 && checks <= 59){
     fee = checks*six;
      newbal+=fee;
        cout<<setprecision(2)<<fixed;  
   cout<<"Balance"<<setw(6)<<"$"<<setw(9)<<balance<<endl;
   cout<<"Check Fee"<<setw(4)<<"$"<<setw(9)<<fee<<endl;
 
   cout<<"Monthly Fee"<<setw(2)<<"$"<<setw(9)<<month<<endl;
   cout<<"Low Balance"<<setw(2)<<"$"<<setw(9)<<lowbal<<endl;
      
  
        newbal+=month;
   newbal=balance-newbal;//new balance including check fees
 
   cout<<"New Balance"<<setw(2)<<"$"<<setw(9)<<newbal;
}
    else if(checks >=60){
     fee =checks*four;
     newbal+=fee;
     
       cout<<setprecision(2)<<fixed;  
   cout<<"Balance"<<setw(6)<<"$"<<setw(9)<<balance<<endl;
   cout<<"Check Fee"<<setw(4)<<"$"<<setw(9)<<fee<<endl;
 
   cout<<"Monthly Fee"<<setw(2)<<"$"<<setw(9)<<month<<endl;
   cout<<"Low Balance"<<setw(2)<<"$"<<setw(9)<<lowbal<<endl;
      
  
        newbal+=month;
   newbal=balance-newbal;//new balance including check fees
 
   cout<<"New Balance"<<setw(2)<<"$"<<setw(9)<<newbal;
    
     
    
}
  
   
    return 0;
}