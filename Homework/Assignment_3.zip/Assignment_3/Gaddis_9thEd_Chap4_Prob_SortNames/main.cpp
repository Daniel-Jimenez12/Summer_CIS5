/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 12, 2022
 * Sorts names alphabetically
 *           
 */

//System Libraries
#include <iostream> 
#include <iomanip>//Input/Output Library
using namespace std;


int main(int argc, char** argv) {
    //Set the random number seed
   
  cout<<"Sorting Names"<<endl;  
    //Declare Variables
  string   x,
           y,
           z;

 cout<<"Input 3 names"<<endl;
 cin>>x>>y>>z;
 //first name is first alphabetically
 if (x<=y && y<=z) {
     cout<<x<<endl;
     cout<<y<<endl;
     cout<<z;
 }
  else if (x<=z && z<=y) {
     cout<<x<<endl;
     cout<<z<<endl;
     cout<<y;
 }
 else if ( y<=x && x<=z) {
     cout<<y<<endl;
     cout<<x<<endl;
     cout<<z;
 }
 else if ( y<=z && z<=x) {
     cout<<y<<endl;
     cout<<z<<endl;
     cout<<x;
 }
  else if (z<=x&& x<=y) {
     cout<<z<<endl;
     cout<<x<<endl;
     cout<<y;
 }
   else { //if (z<=x && x<=y) {
     cout<<z<<endl;
     cout<<y<<endl;
     cout<<x;
 }
    return 0;
}