
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 14, 2022
 * calculates inflation for item after one year and two years 
 */


#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;

const int percent = 100;
int main(int argc, char** argv) {
   char again ;
    
    float  irate,
          oneyear,
          twoyear,
             cprice,
          yearprice;
do{
cout<<"Enter current price:"<<endl;
   cin>>cprice;//current new price
cout<<"Enter year-ago price:"<<endl;
   cin>>yearprice;//the price it was a year ago
   
  cout<<fixed<<setprecision(2)<<showpoint;
  irate =((cprice-yearprice)/yearprice)*percent;//the inflation rate of the item 
           //(current price -year ago price)/year ago price)*percent conversion
cout<<"Inflation rate: "<<irate<<"%"<<endl<<endl;
    oneyear=((irate*cprice)/percent)+cprice;//price in one year is 
   //(inflation rate * current price)/percent + back to current price
cout<<"Price in one year: $"<<oneyear<<endl;
twoyear=((irate*oneyear)/percent)+oneyear;//two year price is 
                            //(rate*/oneyear price )/percent + one year price
cout<<"Price in two year: $"<<twoyear<<endl<<endl;

cin>>again;
cout<<"Again:"<<endl;

if(again == 'Y' || again=='y'){
    cout<<endl;
}
}while(again =='y' || again == 'Y');

return 0 ;
}  
   
 
