
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July 14 2022
 * prints rectangle shape for integer and character chosen
 */

//System libraries 
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    int size;
    char letter;
   
    cin>>size>>letter;//grabs size based off of integer and the character 
                      // chosen to print
    

    
for(int col=1;col<=size;col++){
    
    for(int rows=1;rows<=size;rows++){//increments to the specified integer
        
         cout<<letter;//then prints character to the increment number
          
       
    }
   
    if(col!=size){
            cout<<endl;//places endl after every column except when column 
                       //equals the size
            
        }
}
    return 0 ;

}