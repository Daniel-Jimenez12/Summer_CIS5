
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July 14 2022
 * prints pattern that increases to 10 and then decreases back to 1
 * in triangle shape
 */

//System libraries 

#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {   

    int length;
    
    cin>>length;
    

    for(int rows =1;rows<=length;rows++){
      for(int cols=1;cols<=rows;cols++)  {
          
       cout<<'+';//prints the character incremented up to specified length 
       
   }
   cout<<endl<<endl;
}
    for(int rows=1;rows<=length;rows++){
        for(int cols=1;cols<=(length+1)-rows ;cols++) {
         cout<<'+';//decreases the amount of characters printed.one more before
                   //length equals zero 
        }
          if(rows<length){
              cout<<endl<<endl;//prints both endl before the rows equal the size
           }
          

}
    //Exit stage right or left!
    return 0 ;
}