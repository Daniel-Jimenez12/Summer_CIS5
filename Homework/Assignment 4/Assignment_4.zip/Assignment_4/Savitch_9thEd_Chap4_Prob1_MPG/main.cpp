
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 14, 2022
 * converts liters to gallons and displays miles per gallon a car used
 */


#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
   const float literper = 0.264179;//one liter to one gallon 
//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float mpg,
         miles,
         liters;
     char again;  

  do{ 
      
    
      
    cout<<"Enter number of liters of gasoline:"<<endl;
      cin>>liters;
      cout<<endl;
    cout<<"Enter number of miles traveled:"<<endl;
      cin>>miles;
    cout<<endl;
   cout<<"miles per gallon:"<<endl;
        mpg=miles/(literper*liters);//miles/gallons = miles per gallon
        cout<<fixed<<setprecision(2);
        cout<<mpg<<endl;
        cout<<"Again:"<<endl;
        
        cin>>again;
        if(again =='Y'||again=='y'){
            cout<<endl;
        }

         }while(again=='Y'||again=='y');//user chooses to continue entering
    return 0;
}


