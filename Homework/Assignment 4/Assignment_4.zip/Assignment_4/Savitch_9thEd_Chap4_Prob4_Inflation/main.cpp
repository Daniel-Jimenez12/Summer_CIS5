
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 14, 2022
 * calculates inflation for item 
 */


#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;

int main(int argc, char** argv) {
    char again ;
    
    float  irate,
             cprice,
           yearprice;
do{
cout<<"Enter current price:"<<endl;
   cin>>cprice;//current price
cout<<"Enter year-ago price:"<<endl;
   cin>>yearprice;//price a year ago
   
  cout<<fixed<<setprecision(2);
irate =((cprice-yearprice)/yearprice)*100;//rate = current price-year ago price
                                         //divided by year ago as a percent
cout<<"Inflation rate: "<<irate<<"%"<<endl<<endl;

cout<<"Again:"<<endl;
cin>>again;
if(again == 'Y' || again=='y'){//user choice to continue
    cout<<endl;
}
}while(again =='y' || again == 'Y');

return 0 ;
}