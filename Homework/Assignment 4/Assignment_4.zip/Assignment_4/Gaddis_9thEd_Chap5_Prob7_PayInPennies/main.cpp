
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July 14 2022
 * 
 */

//System libraries 
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

int main (int argc, char** argv) {
//Function Prototypes
unsigned int      payd,
                  pays,
                  days;      
payd=1;
pays=payd;
//Execution Begins Here!

    cin>>days;
    
   for(int x = 2;x<=days;x++) {
    payd*=2;
    pays+=payd;
    //Declare Variables
   } 
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    
    //Display the outputs
int dollar  = pays/100;
int pennies = pays%100;

cout<<"Pay = $"<<dollar<<"."<<(pennies<10?"0":"")<<pennies;
    //Exit stage right or left!
    return 0;
}