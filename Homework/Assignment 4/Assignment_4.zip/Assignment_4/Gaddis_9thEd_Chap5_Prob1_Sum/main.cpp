
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 14, 2022
 * displays sum of a sequence of integers 
 */



#include <iostream>
using namespace std;
int main(int argc, char** argv) {
    int num,
        sum;
    sum=0;
    cin>>num;
for(int x = 0; x<=num;++x){
  sum+=x;//adds integers to each other after each increment
    
} 
    cout<<"Sum = "<<sum;//displays sum of integers
   return 0;
}
