
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 14, 2022
 * calculates the max of two parameters and three parameters
 */


#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;
int main(int argc, char** argv) {
    
    float max1,
          max2,
          num1,
          num2,
          num3;
    cout<<"Enter first number:"<<endl;
        cin>>num1;
    cout<<endl;
    cout<<"Enter Second number:"<<endl;
        cin>>num2;
        cout<<endl;
    cout<<"Enter third number:"<<endl;
         cin>>num3;
    cout<<endl;
  if(num1>num2){//first set of two 
      max1=num1;
}else 
   max1=num2;
    cout<<"Largest number from two parameter function:"<<endl<<max1<<endl;
 
    cout<<endl;
    
   if(max1<num3){//compares max of first two set to the third parameter 
       max2=num3;//compares first max to last parameter
   }else
    max2=max1;
    //if max from first set is larger.that number is the max of both
    
    cout<<"Largest number from three parameter function:"<<endl<<max2<<endl;
    return 0;
}