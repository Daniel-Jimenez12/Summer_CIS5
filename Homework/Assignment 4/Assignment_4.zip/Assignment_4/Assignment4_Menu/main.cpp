
/* 
 * File:   main.cpp
 * Author: 2832229
 *
 * Created on June 21, 2022, 12:02 PM
 */

//System libraries 


#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;  //STD Name-space where Library is compiled


int main(int argc, char** argv) {
    int choose;//Choose a problem
    do{
        //List of Problems which can be run by the program
        cout<<endl;
        cout<<"Choose from the following Menu Items"<<endl;
        cout<<"Problem 0"<<endl;
        cout<<"Problem 1"<<endl;
        cout<<"Problem 2"<<endl;
        cout<<"Etc......"<<endl;
        cout<<"10 or greater, all negatives to exit"<<endl;
        cin>>choose;
        
        switch(choose){//prob1 Sum
            case 0:{  int num,
                          sum;
                         sum=0;
                        cout<<"insert integer"<<endl;
                    cin>>num;
            for(int x = 0; x<=num;++x){
                sum+=x;//adds integers to each other after each increment
    
} 
                cout<<"Sum = "<<sum;//displays sum of integers
            }
break;
            case 1:{//prob2 Pay in pennies 
                unsigned int   payd,pays,days;      
                        payd=1;
                        pays=payd;
                        cout<<"Insert Days"<<endl;
                        cin>>days;
                for(int x = 2;x<=days;x++) {
                    payd*=2;
                    pays+=payd;
    
   } 
                    int dollar  = pays/100;
                    int pennies = pays%100;
                   cout<<"Pay = $"<<dollar<<"."<<(pennies<10?"0":"")<<pennies;

            }
break;
            case 2:{//prob3 min max
               int small,
                   large,
                     num;
               cout<<"insert num and -99 to quit "<<endl;
                       cin>>num;
                small=large=num;
         while(num != -99){//user types -99 to quit execution
             if(num < small ){ //&& num != -99){
                small = num;
        }else if(num > large){ //&& num != -99){
              large = num;
        }else
                 num=num;
                cin>>num;
         }
           cout<<"Smallest number in the series is "<<small<<endl;
           cout<<"Largest  number in the series is "<<large;
}break;
            case 3:{//prob4 rectangle
                int size;
                char letter;
                cout<<"choose size and character to print"<<endl;
           cin>>size>>letter;
         for(int col=1;col<=size;col++){
           for(int rows=1;rows<=size;rows++){
                  cout<<letter;
               }
            if(col!=size){
            cout<<endl;
           }
         }
                
   }break;
            case 4:{//prob5 pattern
                int length;
                cout<<"Enter length"<<endl;
                 cin>>length;
    for(int rows =1;rows<=length;rows++){
      for(int cols=1;cols<=rows;cols++)  {
           cout<<'+'; 
           }
        cout<<endl<<endl;
      }
    for(int rows=1;rows<=length;rows++){
        for(int cols=1;cols<=(length+1)-rows ;cols++) {
              cout<<'+';
            }
          if(rows<length){
              cout<<endl<<endl;//prints both endl before the rows equal the size
           }
          

         }
   }break;
            case 5:{//prob6 mpg
                float mpg,
                 literper,
                   miles,
                  liters;
     char again;  
  literper = 0.264179;
  do{ 
      
    
      
    cout<<"Enter number of liters of gasoline:"<<endl;
      cin>>liters;
      cout<<endl;
    cout<<"Enter number of miles traveled:"<<endl;
      cin>>miles;
    cout<<endl;
   cout<<"miles per gallon:"<<endl;
        mpg=miles/(literper*liters);//miles/gallons = miles per gallon
        cout<<fixed<<setprecision(2);
        cout<<mpg<<endl;
        cout<<"Again:"<<endl;
        
        cin>>again;
        if(again =='Y'||again=='y'){
            cout<<endl;
        }

         }while(again=='Y'||again=='y');
}break;
            case 6:{//prob7 fuel eff
                  float literper,mpg1,mpg2,miles1,miles2,liters1,liters2;
                    char again;  
                    literper=0.264179;
  do{ 
      
    //Car 1
    cout<<"Car 1"<<endl;
    cout<<"Enter number of liters of gasoline:"<<endl;
       cin>>liters1;//first number of liters
    cout<<"Enter number of miles traveled:"<<endl;
       cin>>miles1;//first number of miles
       mpg1=miles1/(literper*liters1);//mpg conversion
     cout<<fixed<<setprecision(2);
     cout<<"miles per gallon: "<<mpg1<<endl<<endl;//mpg for car1
     //Car 2
      cout<<"Car 2"<<endl;
    cout<<"Enter number of liters of gasoline:"<<endl;
       cin>>liters2;
    cout<<"Enter number of miles traveled:"<<endl;
       cin>>miles2;
       mpg2=miles2/(literper*liters2);
     cout<<fixed<<setprecision(2);
     cout<<"miles per gallon: "<<mpg2<<endl<<endl;
        if(mpg1>mpg2){//compares which mpg is larger
      cout<<"Car 1 is more fuel efficient"<<endl;//larger mpg is more efficient
     }else if(mpg1<mpg2){//if mpg for car 2 is larger
         cout<<"Car 2 is more fuel efficient"<<endl;
     }
     cout<<endl;
     cout<<"Again:"<<endl;
        
        cin>>again;
        if(again =='Y'||again=='y'){
            cout<<endl;//prints endl if user chooses to execute once more
        }
           
         }while(again=='Y'||again=='y');
            }break;
            
            case 7:{//prob 8 inflation
                char again ;
    
    float  irate,cprice,yearprice;
                    do{
                cout<<"Enter current price:"<<endl;
                    cin>>cprice;//current price
                cout<<"Enter year-ago price:"<<endl;
                    cin>>yearprice;//price a year ago
   
                cout<<fixed<<setprecision(2);
irate =((cprice-yearprice)/yearprice)*100;//rate = current price-year ago price
                                         //divided by year ago as a percent
cout<<"Inflation rate: "<<irate<<"%"<<endl<<endl;
cout<<"Again:"<<endl;
      cin>>again;
   if(again == 'Y' || again=='y'){//user choice to continue
         cout<<endl;
        }
}while(again =='y' || again == 'Y');
            }break;
            case 8:{//prob 9 est cost
               char again ;
    
    float  irate,oneyear,twoyear,cprice,yearprice;
                        do{
                cout<<"Enter current price:"<<endl;
                    cin>>cprice;//current new price
                cout<<"Enter year-ago price:"<<endl;
                          cin>>yearprice;//the price it was a year ago
   
  cout<<fixed<<setprecision(2)<<showpoint;
  irate =((cprice-yearprice)/yearprice)*100;//the inflation rate of the item 
           //(current price -year ago price)/year ago price)*percent conversion
cout<<"Inflation rate: "<<irate<<"%"<<endl<<endl;
    oneyear=((irate*cprice)/100)+cprice;//price in one year is 
   //(inflation rate * current price)/percent + back to current price
cout<<"Price in one year: $"<<oneyear<<endl;
twoyear=((irate*oneyear)/100)+oneyear;//two year price is 
                            //(rate*/oneyear price )/percent + one year price
cout<<"Price in two year: $"<<twoyear<<endl<<endl;


cout<<"Again:"<<endl;
cin>>again;
if(again == 'Y' || again=='y'){
    cout<<endl;
}
}while(again =='y' || again == 'Y');  
            }break;
            case 9:{//prob10 2or3max
               float max1,
          max2,
          num1,
          num2,
          num3;
    cout<<"Enter first number:"<<endl;
        cin>>num1;
    cout<<endl;
    cout<<"Enter Second number:"<<endl;
        cin>>num2;
        cout<<endl;
    cout<<"Enter third number:"<<endl;
         cin>>num3;
    cout<<endl;
  if(num1>num2){//first set of two 
      max1=num1;
}else 
   max1=num2;
    cout<<"Largest number from two parameter function:"<<endl<<max1<<endl;
 
    cout<<endl;
    
   if(max1<num3){//compares max of first two set to the third parameter 
       max2=num3;//compares first max to last parameter
   }else
    max2=max1;
    //if max from first set is larger.that number is the max of both
    
    cout<<"Largest number from three parameter function:"<<endl<<max2<<endl; 
            }break;
            default:cout<<"Exiting the Menu"<<endl;
        }
    }while(choose >= 0 && choose <= 9);

    return 0;
}

    
    