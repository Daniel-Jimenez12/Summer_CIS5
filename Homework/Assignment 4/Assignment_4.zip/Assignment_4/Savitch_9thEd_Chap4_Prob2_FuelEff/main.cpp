
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 14, 2022
 * calculates miles per gallon for two cars
 * then compares fuel efficiency of both
 */


#include <iostream>  
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
   const float literper = 0.264179;//one liter to one gallon 
//Execution Begins Here!
int main(int argc, char** argv) {
    float mpg1,
         mpg2,
         miles1,
         miles2,
         liters1,
         liters2;
     char again;  

  do{ 
      
    //Car 1
    cout<<"Car 1"<<endl;
    cout<<"Enter number of liters of gasoline:"<<endl;
       cin>>liters1;//first number of liters
    cout<<"Enter number of miles traveled:"<<endl;
       cin>>miles1;//first number of miles
       mpg1=miles1/(literper*liters1);//mpg conversion
     cout<<fixed<<setprecision(2);
     cout<<"miles per gallon: "<<mpg1<<endl<<endl;//mpg for car1
     //Car 2
      cout<<"Car 2"<<endl;
    cout<<"Enter number of liters of gasoline:"<<endl;
       cin>>liters2;
    cout<<"Enter number of miles traveled:"<<endl;
       cin>>miles2;
       mpg2=miles2/(literper*liters2);
     cout<<fixed<<setprecision(2);
     cout<<"miles per gallon: "<<mpg2<<endl<<endl;
        if(mpg1>mpg2){//compares which mpg is larger
      cout<<"Car 1 is more fuel efficient"<<endl;//larger mpg is more efficient
     }else if(mpg1<mpg2){//if mpg for car 2 is larger
         cout<<"Car 2 is more fuel efficient"<<endl;
     }
     cout<<endl;
     cout<<"Again:"<<endl;
        
        cin>>again;
        if(again =='Y'||again=='y'){
            cout<<endl;//prints endl if user chooses to execute once more
        }
           
         }while(again=='Y'||again=='y');
    return 0;
}

