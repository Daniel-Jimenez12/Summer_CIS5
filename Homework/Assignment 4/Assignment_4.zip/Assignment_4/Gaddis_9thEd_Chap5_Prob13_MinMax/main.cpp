
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *displays min and max of sequence of integers
 * Created on July 14 2022
 */

//System libraries 
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

int main(int argc, char** argv) {
    int 
     small,
     large,
      num;

//small=0;
//large=0;
  cin>>num;
    small=large=num;
         while(num != -99){    //user types -99 to quit execution

            
            //small=num;
           if(num < small ){ //&& num != -99){
            
              small = num;
        }
        else if(num > large){ //&& num != -99){
              large = num;
        }else
         num=num;
        cin>>num;
       
    }
        

 cout<<"Smallest number in the series is "<<small<<endl;

 cout<<"Largest  number in the series is "<<large;
    return 0;
}