
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 * Created on July 6, 2022
 * calculates retroactive pay and new monthly and yearly salary 
 */

//System libraries 
#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float annual,
             six,
          percent,
          newsal,//new annual salary
          retro,//retroactive pay
          month;//new monthly salary
         
        
         percent=.076;
    cout<<"Input previous annual salary."<<endl;
    cin>>annual;
     six = annual/2;
    cout<<fixed<<setprecision(2)<<showpoint;
           retro = six*percent;
    cout<<"Retroactive pay    = $"<<setw(7)<<retro<<endl;
         
         newsal = (annual *percent)+annual;
    cout<<"New annual salary  = $"<<setw(7)<<newsal<<endl;
          
           month = ((six/6.0)*percent)+(six/6.0);
    cout<<"New monthly salary = $"<<setw(7)<<month;
     

    //Exit stage right or left!
    return 0;
}
