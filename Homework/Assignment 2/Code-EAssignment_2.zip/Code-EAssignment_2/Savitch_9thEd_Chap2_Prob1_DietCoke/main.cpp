
/* 
 * File:   main.cpp
 * Author:Daniel Jimenez
 *
 * Created on July 6, 2022, 
 * calculates amount of cans of soda could kill you 
 */


#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float mousegram,//mouse weight in grams
    msweet,
    dgrams,//dieghter weight in grams
    mdose,
    
    poundgram,
    weight;
    int cans;
    //sodagrams;
   
    //Declare Variables
    msweet = 5.00;//dose of sweetener that could kill the mouse
    mousegram=35.00;//mouse weighs 35 grams
    poundgram= 453.592;//grams per 1 pound
    //sodagrams=.35;//amount of grams in soda
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
   // cout<<fixed<<setprecision(0)<<showpoint;
    cout<<fixed<<setprecision(1)<<showpoint;
     cout<<"Program to calculate the limit of Soda Pop Consumption."<<endl;
     cout<<"Input the desired dieters weight in lbs."<<endl;
        cin>>weight;
        float ldose;
        //dgrams= weight*poundgram;//dieter weight in grams
        mdose=msweet/mousegram; //lethal dose for mouse in proportion to the human
        ldose= mdose *(weight*453.592);//the lethal dose for a human 
          
    
     
    cout<<"The maximum number of soda pop cans"<<endl;
    cans =ldose/(350*.001);//how many cans can dieter drink until lethal dose
 ;
     
    cout<<"which can be consumed is "<<cans<<" cans";
    //Display the outputs

    //Exit stage right or left!
    return 0;
}
