
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *created on July,6, 2022
 * 
 * how many total calories were consumed from user input of cookies.
 */

//System libraries 
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <ctime>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float //Declare Variables
    cookies,
    cookiesperServ,
    calperserv,
    ate;
    cout<<"Calorie Counter"<<endl;
      //Initialize or input i.e. set variable values
    cookiesperServ =40/10;//serving per cookie 
    calperserv = 300;//calories per serving
    
  
  
     cout<<"How many cookies did you eat?"<<endl;
     cin>>cookies;
     ate = cookies/cookiesperServ*calperserv;
    //Map inputs -> outputs
    cout<<"You consumed "<<ate<<" calories.";
    //Exit stage right or left!
    return 0;
}
