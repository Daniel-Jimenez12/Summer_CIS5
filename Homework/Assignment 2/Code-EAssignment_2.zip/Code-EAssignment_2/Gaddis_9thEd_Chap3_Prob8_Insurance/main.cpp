
/* 
 * File:   main.cpp
 * Author:Daniel Jimenez
 *
 * Created on July 6 , 2022, 
 * displays the minimum amount of insurance user should buy 
 */

//System libraries 

#include <iostream>

using namespace std;
//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    cout<<"Insurance Calculator"<<endl;
    //Declare Variables
    float worth,
        percent,
      insurance; 
    
    //Initialize or input i.e. set variable values
   //worth = 500000;
   percent =0.80;
   
    //Map inputs -> outputs
     cout<<"How much is your house worth?"<<endl;
    cin>>worth;
    insurance = worth*percent;
    //Display the outputs
cout<<"You need $"<<insurance<<" of insurance.";
return 0;
}
    //Exit stage right or left!