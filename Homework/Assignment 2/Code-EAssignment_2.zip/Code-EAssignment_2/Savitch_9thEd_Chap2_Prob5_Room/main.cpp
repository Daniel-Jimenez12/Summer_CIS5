
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July 6, 2022
 * determines if meeting is in violation of overcapacity
 * 
 */
#include <iostream> 
#include <cmath>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    int    attendees,
            reduce,
            additional,
            maxcap;
    //display results 
    cout<<"Input the maximum room capacity and the number of people"<<endl;
        cin>>attendees>>maxcap;
    
    if (attendees>=maxcap ){
      cout<<"Meeting can be held."<<endl;
       additional=attendees-maxcap;//finds difference to see if more can attend
       cout<<"Increase number of people by "<<additional<<" will be allowed without violation.";
    }else if (attendees < maxcap){
    cout<<"Meeting cannot be held."<<endl;
           reduce = (maxcap-attendees);//number needed to reduce capacity
    cout<<"Reduce number of people by "<<reduce<<" to avoid fire violation.";
    }
    return 0;
}
