
/* 
 * File:   main.cpp
 * Author Daniel Jimenez
 *
 * Created on July 6, 2022
 * converts temp  from Fahrenheit to Celsius
 */

//System libraries 

#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;
//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    //Declare Variables
    float cel,
          faren;
          cout<<"Temperature Converter"<<endl;
    //Initialize or input i.e. set variable values
    faren = 212;
   cout<<"Input Degrees Fahrenheit"<<endl;
   cin>>faren;
   
    //Map inputs -> outputs
    cel = 5.0/9*(faren-32);
    //Display the outputs
    cout<<fixed<<setprecision(1)<<showpoint;
   cout<<faren<<" Degrees Fahrenheit = "<<cel<<" Degrees Centigrade";
    //Exit stage right or left!
    return 0;
}