
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July 6, 2022
 * calculates sin cos and tan of angle
 */
//System Libraries
#include <iostream> 
#include <cmath>
#include<iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
          float degree,
          degreeRad;
cout<<"Calculate trig functions"<<endl;
    //Declare Variables
 cout<<"Input the angle in degrees."<<endl;
 cin>>degree;
    degreeRad= degree*(3.14159265359/180);
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
  
   cout<<fixed<<setprecision(4)<<showpoint;
   cout<<"sin("<<(int)degree<<") = "<<sin(degreeRad)<<endl;
   cout<<"cos("<<(int)degree<<") = "<<cos(degreeRad)<<endl;
   cout<<"tan("<<(int)degree<<") = "<<tan(degreeRad);
    //Display the outputs

    //Exit stage right or left!
    return 0;
}

