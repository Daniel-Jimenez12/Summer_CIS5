
/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July,6 2022
 * calculates gross pay
 */

#include <iostream>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float payRate,//Pay rate in $'s per hour 
    hrsWrkd,//hours worked 
    paych;//Paycheck in $
    //Initialize or input i.e. set variable values
   
    //Map inputs -> outputs
    cout<<"This program calculates the gross paycheck."<<endl;
    cout<<"Input the pay rate in $'s/hr and the number of hours."<<endl;
     cin>>payRate>>hrsWrkd;
    paych=payRate*hrsWrkd;
    paych+=hrsWrkd>40?payRate*(hrsWrkd-40):0;
    //Display the outputs
    cout<<fixed<<setprecision(2)<<showpoint;
    cout<<"Paycheck = $"<<setw(7)<<paych;
    //Exit stage right or left!
    return 0;
}