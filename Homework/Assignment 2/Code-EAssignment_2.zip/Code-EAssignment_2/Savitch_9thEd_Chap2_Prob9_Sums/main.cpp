/* 
 * File:   main.cpp
 * Author: Daniel Jimenez
 *
 * Created on July 6, 2022
 * displays negative,positive and total sum of 10 numbers 
 */
#include <iostream>
#include<iomanip>//Input/Output Library
using namespace std;
int main(int argc, char** argv) {

  int pos,
  neg,
  total,
  num1,
  num2,
  num3,
  num4,
  num5,
  num6,
  num7,
  num8,
  num9,
  num10;
  //Declare variables
  neg = 0;
  pos = 0;
  total = 0;
  
  
  cout<<"Input 10 numbers, any order, positive or negative"<<endl;
  
  
  cin >> num1;
  total+= num1;
 if (num1>0)  //num1
     pos+= num1; //add to positive total 
  else
      neg += num1; //add to negative total 
  
  cin >> num2;//num2
  total += num2;
 if(num2>0)       
    pos += num2;   
  else
    neg += num2; 
   
cin >> num3;
  total+= num3;
  
 if (num3>0) //num3
     pos+= num3; //add to positive total 
  else
      neg += num3;//add to negative total 
     
  cin >> num4;//num4
  total += num4;
 if(num4>0)        
    pos += num4;   
  else
    neg += num4; 
  
    cin >> num5;
  total+= num5;
 if (num5>0) //num5
     pos+= num5;//add to positive total 
  else
      neg += num5; //add to negative total 
      
  cin >> num6;//num6
  total += num6;
 if(num6>0)        
    pos += num6;   
  else
    neg += num6; 
    
    cin >> num7;
  total+= num7;
 if (num7>0)  //num6
     pos+= num7; //add to positive total 
  else
      neg += num7; //add to negative total 
      
  cin >> num8;//num7
  total += num8;
 if(num8>0)        
    pos += num8;   
 else
    neg += num8; 
  
  
cin >> num9;
  total+= num9;
 if (num9>0) //num8
     pos+= num9;//add to positive total 
  else
      neg += num9; //add to negative total 
  
  
  cin >> num10;//num9
  total += num10;
 if(num10>0)
 
    pos += num10;   
  else
    neg += num10; 
  
 
   
    cout<<"Negative sum ="<<setw(4)<<neg<<endl;
    cout<<"Positive sum ="<<setw(4)<<pos<<endl;
    cout<<"Total sum    ="<<setw(4)<<total;
  return 0;
  
}

