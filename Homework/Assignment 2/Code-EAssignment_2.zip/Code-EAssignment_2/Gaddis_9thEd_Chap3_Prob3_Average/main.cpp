/* 
 * File:   main.cpp
 * Author:Daniel Jimenez
 * Created on January 6, 2022, 6:55PM
 * calculate the average
 * purpose:average test score and display it.
 */

//System Libraries
#include <iostream> 
#include <cmath>
#include <iomanip>//Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    float n1,
        n2,
        n3,
        n4,
        n5,
        avg;
        
    //Declare Variables
    
    //Initialize or input i.e. set variable values
    n1 = 1;
    n2 = 2;
    n3 = 3;
    n4 = 4;
    n5 = 5;
    //Map inputs -> outputs
 
  
    //Display the outputs
cout<<setprecision(1)<<fixed<<showpoint;  
cout<<"Input 5 numbers to average."<<endl;
cin>>n1;
 cin>>n2;
 cin>>n3;
 cin>>n4;
 cin>>n5;
 avg=(n1+n2+n3+n4+n5)/5.0;
cout <<"The average = "<< avg;
    //Exit stage right or left!
    return 0;
}



